function showHome() {
    document.getElementById('home').style.display = 'block';
    document.getElementById('players').style.display = 'none';
    document.getElementById('history').style.display = 'none';
  }
  
  function showPlayers() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('players').style.display = 'block';
    document.getElementById('history').style.display = 'none';
    
  }
  
  function showHistory() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('players').style.display = 'none';
    document.getElementById('history').style.display = 'block';
    
  }
  
  
  